package com.salurysrcp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salurysrcp.dao.AppointmentDao;
import com.salurysrcp.entity.Appointment;

@Service
public class AppointmentService {

	@Autowired
	private AppointmentDao appointmentDao;
	
	public Appointment Appointmentsave(Appointment appointment) {
	
		Appointment app=appointmentDao.save(appointment);
		return app;
	}
	public Appointment getStatus(int userid) {
		Appointment app=appointmentDao.getStatus(userid);
		return app;
	}
	public int getUser(int userid) {
		int count =appointmentDao.getUser(userid);
		return count;
	}
	public List<Appointment> getRequest(){
		List<Appointment> list=appointmentDao.getRequstes();
		return list;
	}
	public void deleteRequest(int userid) {
		appointmentDao.deleteRequest(userid);
	}
}
