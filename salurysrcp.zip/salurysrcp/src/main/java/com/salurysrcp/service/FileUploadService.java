package com.salurysrcp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salurysrcp.dao.FileUploadDao;
import com.salurysrcp.dao.UserRegisterDao;
import com.salurysrcp.entity.FileUpload;
import com.salurysrcp.entity.UserRegister;

@Service
public class FileUploadService {
	
	@Autowired
	private FileUploadDao fileUploadDao;
	@Autowired()
	private UserRegisterDao userRegisterDao;
	public void saveFile(FileUpload file) {
		fileUploadDao.save(file);
	}
	public int getCount(int uid) {
		int count=fileUploadDao.getCount(uid);
		return count;
	}
	public UserRegister getUser(int uid) {
		UserRegister user=userRegisterDao.findByUid(uid);
		return user;
	}
	public FileUpload getphoto(int uid) {
		FileUpload file=fileUploadDao.getPhoto(uid);
		

		return file;
	}
	public FileUpload getAadhar(int uid) {
		FileUpload file=fileUploadDao.getAadhar(uid);
		

		return file;
	}
	public List<FileUpload> updatephoto(int uid) {
		List<FileUpload> file=fileUploadDao.updatephoto(uid);
		return file;
	}
	public List<FileUpload> allPhotos() {
		List<FileUpload> file=fileUploadDao.allPhotos();
		return file;
	}
}
