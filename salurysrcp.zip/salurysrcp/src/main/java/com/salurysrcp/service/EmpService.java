package com.salurysrcp.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salurysrcp.dao.DepartmentDao;
import com.salurysrcp.dao.EmployeeDao;
import com.salurysrcp.entity1.Department;
import com.salurysrcp.entity1.Employee;
@Service
public class EmpService {
@Autowired()
private EmployeeDao ed;
@Autowired DepartmentDao dd;
public void depsave(Department dept) {
	// TODO Auto-generated method stub
	dd.save(dept);
}
public void empsave( Employee emp) {
	// TODO Auto-generated method stub
	ed.save(emp);
}
public Department getDept(int dno) {
	Department d=dd.findBydeptNo(dno);
	return d;
}
public Employee getEmployee(int eno) {
	// TODO Auto-generated method stub
	
	return ed.findByempNo(eno);
}
public Employee updatetEmployee(int eno,String ename) {
	Employee e=ed.findByempNo(eno);
	e.setEmpName(ename);
	return ed.save(e);
}



}
