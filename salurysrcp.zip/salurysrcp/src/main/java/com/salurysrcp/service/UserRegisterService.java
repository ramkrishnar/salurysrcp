package com.salurysrcp.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salurysrcp.dao.UserRegisterDao;
import com.salurysrcp.entity.UserRegister;
@Service()
public class UserRegisterService {

	@Autowired()
	private UserRegisterDao userRegisterDao;
	
	
	public UserRegister userSave(UserRegister user) {
		UserRegister users=new UserRegister();
		users=userRegisterDao.save(user);
		return users;
	}
	
	public UserRegister userLogin(String email,String password) {
		
		UserRegister user = userRegisterDao.findByEmailAndPassword(email, password);
		System.out.println(password+"vvvvvvvvvvvvvvvvvvvvvvvvvvvv"+user.getFullname());
		return user;
	}
	public UserRegister forgetpassword(String email,String password) {
		UserRegister user=userRegisterDao.findByEmail(email);
		user.setPassword(password);
		return user;
	}
	 public UserRegister getUserProfile(int uid) {
		 UserRegister user=userRegisterDao.getUserDetails(uid);
		 return user;
	 }
	 public List<UserRegister> getVillageList(String village){
		 return userRegisterDao.getVillageList(village);
	 }
	 public UserRegister getPhoto(int uid) {
		 UserRegister user=userRegisterDao.getPhoto(uid);
		 return user;
		 
	 }
	 public UserRegister updateUser(String fullname,String fathername,String mobile,String dob,String gender,String email,String village,String town,int wardno,String street,int uid) {
		 UserRegister user=userRegisterDao.updateUser(fullname, fathername, mobile, dob, gender, email, village, town, wardno, street, uid);
	return user;
	 }

	public List<UserRegister> getTownList(String town) {
		// TODO Auto-generated method stub
		 return userRegisterDao.getTownList(town);
	}
	public List<UserRegister> geBlockedUser() {
		// TODO Auto-generated method stub
		 return userRegisterDao.getBlockedUsers();
	}

}
