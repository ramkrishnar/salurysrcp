package com.salurysrcp.config;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.salurysrcp.entity.UserRegister;

public class CustomValidation implements Validator {
 
    public boolean supports(Class<?> clazz) {
        return UserRegister.class.isAssignableFrom(clazz);
    }
 
    public void validate(Object target, Errors errors) {
    	UserRegister user = (UserRegister)target;
        
        String password = user.getPassword();
        String confPassword = user.getConfirmpassword();
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "age", "customer.age.empty");
       
        //Business validation
        if(!password.equals(confPassword)){
            errors.rejectValue("password","customer.password.missMatch");
        }
       
   
    }

}
