package com.salurysrcp.entity1;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="employee")
public class Employee {
	public Employee() {
		
	}
	@Id
	@GeneratedValue(generator="myGenerator")
	@GenericGenerator(name="myGenerator",
	strategy="increment")
	private int empNo;
	private String empName;
	private double salary;
	private int dno;
	
	
	@ManyToOne
	@JoinColumn(name="dept_no")
	private Department dept;//may to one
	public int getDno() {
		return dno;
	}
	public void setDno(int dno) {
		this.dno = dno;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
}
