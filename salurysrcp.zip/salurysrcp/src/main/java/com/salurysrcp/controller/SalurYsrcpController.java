package com.salurysrcp.controller;

import java.io.IOException;
import java.util.ArrayList;
//import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.List;

//import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;

//import org.springframework.mail.MailMessage;

import org.springframework.ui.Model;
//import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.salurysrcp.dao.DepartmentDao;
import com.salurysrcp.entity.Appointment;
import com.salurysrcp.entity.FileUpload;
import com.salurysrcp.entity.UserRegister;
import com.salurysrcp.entity1.Department;
import com.salurysrcp.entity1.Employee;
import com.salurysrcp.gmail.SendMailing;
import com.salurysrcp.service.AppointmentService;
import com.salurysrcp.service.EmpService;
import com.salurysrcp.service.FileUploadService;
import com.salurysrcp.service.UserRegisterService;



@RestController
@RequestMapping(value="/user")
public class SalurYsrcpController {

	@Autowired()
	private UserRegisterService userRegisterService;
	@Autowired()
	private FileUploadService fileUploadService;
	@Autowired()
	private AppointmentService appointmentService;
	 EmpService es=new EmpService();
	 @CrossOrigin()
	@GetMapping(value="/home")
	public ModelAndView home() {
		ModelAndView mv=new ModelAndView("home");
		mv.addObject("dept" ,new Department());
		
		return mv;
	}
	    
	 
	@GetMapping(value="/userRegister")
	public ModelAndView regiEmp(Model model) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("userRegister");
		model.addAttribute("user", new UserRegister());
		
		return mv;
	}
	
	
	@GetMapping(value="/updateprofile")
	public ModelAndView updateprofile(Model model) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("EditProfile");
		model.addAttribute("user", new UserRegister());
		
		return mv;
	}
	@GetMapping(value="/addapointment")
public ModelAndView addappointment(Model model) {
	ModelAndView mv=new ModelAndView();
	mv.setViewName("addapointmentdates");
	model.addAttribute("appointment", new Appointment());
	
	return mv;
}
	
	@GetMapping(value="/appointmentBackGround")
	public ModelAndView appointmentBackGroundVerifcation(Model model) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("AppointmentBackGround");
		model.addAttribute("appointment", new Appointment());
		
		return mv;
	}
	
	
	/*@GetMapping(value="/appointmentstatus")
	public ModelAndView addappointmentstatus(Model model) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("appointmentstatus");
		model.addAttribute("appointment", new Appointment());
		
		return mv;
	}*/
	@GetMapping(value="/uploadphoto")
	public ModelAndView uploadphotos(Model model) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("uploadimage");
		model.addAttribute("user", new UserRegister());
		
		return mv;
	}
	@GetMapping(value="/welcometo")
	public ModelAndView welcome(Model model) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("welcome");
		model.addAttribute("user", new UserRegister());
		
		return mv;
	}
	@GetMapping(value="/forgetpwd")
	public ModelAndView forget(Model model) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("forgetpassword");
		model.addAttribute("user", new UserRegister());
		
		return mv;
	}
	@GetMapping(value="/events")
	public ModelAndView events(Model model) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Events");
		model.addAttribute("user", new UserRegister());
		
		return mv;
	}
	@GetMapping(value="/Appointmentverfication")
	public ModelAndView Apointmentverification(Model model,HttpServletRequest req) {
		ModelAndView mv=new ModelAndView();
		String alert="alert alert-danger";
		HttpSession s=req.getSession(false);
		int uid=(int)s.getAttribute("uid");
		UserRegister user=fileUploadService.getUser(uid);
		int count=fileUploadService.getCount(uid);
		if(count==0) {
			String msg="please upload photo,Aadhar And Voter Card";
			mv.addObject("msg", msg);
			mv.addObject("alert", alert);
			mv.setViewName("uploadimage");
			model.addAttribute("user", new UserRegister());
		}
		else {
		mv.setViewName("AppointmentVerfication");
		model.addAttribute("user", new Appointment());
		}
		return mv;
	}

	
	
	@CrossOrigin()
	@RequestMapping(value = "/rootwelcomepage")
	public ModelAndView root(Model model) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("rootwelcome");
		model.addAttribute("user", new UserRegister());
		
		return mv;
	}
	@CrossOrigin()
	@PostMapping(value="/Employeesave")
	public ModelAndView saveemp(@Valid Employee emp,BindingResult result,@RequestParam("dno") int dno) {
		ModelAndView mv=new ModelAndView();
		if(result.hasErrors()) {
		mv.setViewName("register");
		mv.addObject("emp",new Employee());
		return mv;
		}
		Department d=es.getDept(dno);
	emp.setDept(d);
		es.empsave(emp);
		
		mv.addObject("emp",emp);
		mv.setViewName("save");
		return mv;
		
	}
	
	@GetMapping(value="/allRequests")
	public ModelAndView getAllRequstes(Model model) {
		String msg="No Requests Avilable";
		ModelAndView mv=new ModelAndView();
		try {
			
			msg=" ";
			List<Appointment> list=appointmentService.getRequest();
			mv.setViewName("AppointmentBackGround");
			mv.addObject("request", list);
			mv.addObject("msg", msg);
			mv.setViewName("AppointmentBackGround");
			mv.addObject("request", list);
			mv.addObject("msg", msg);
		}
		catch(Exception ex){
			mv.setViewName("AppointmentBackGround");
			mv.addObject("msg", msg);
		}
		return mv;
	}
	

	
	
	@PostMapping(value="/updateRequests")
	public ModelAndView getAllRequests(HttpServletRequest req) {
		String msg="Update successfully";
		ModelAndView mv=new ModelAndView();
		try {
			
			msg=" ";
			List<Appointment> list=appointmentService.getRequest();
			for(Appointment app:list) {
				int userid=app.getUserid();
				String status=req.getParameter("status");
				System.out.println("nnnnnnnnnnnnnnnnnnnnnn"+status);
				Appointment appstatus=appointmentService.getStatus(userid);
				appstatus.setStatus(status);
				appointmentService.Appointmentsave(appstatus);
			}
			mv.setViewName("AppointmentBackGround");
			mv.addObject("request", list);
			mv.addObject("msg", msg);
		}
		catch(Exception ex){
			msg="please try again";
			mv.setViewName("AppointmentBackGround");
			mv.addObject("msg", msg);
		}
		return mv;
	}
	@GetMapping(value="/deleteRequest/{userid}")
	public ModelAndView deleteRequest(@PathVariable("userid") String userid){
		int uid=Integer.parseInt(userid);
		System.out.println("nnnnnnnnnnnnnnnnnnnnnn"+userid);
		String msg="delete successfully";
		ModelAndView mv=new ModelAndView();
		try {
		
		appointmentService.deleteRequest(uid);
		mv.setViewName("AppointmentBackGround");
		mv.addObject("msg", msg);
		}
		catch(Exception ex) {
			msg="Request not deleted !please try again";
			mv.setViewName("AppointmentBackGround");
			mv.addObject("msg", msg);
		}
		return mv;
		
	}
	@PostMapping(value="/addapointmentReq")
	public ModelAndView addAppointmentReq(@Valid @ModelAttribute("appointment") Appointment appointment,
			BindingResult result,
			HttpServletRequest req) {
		ModelAndView mv=new ModelAndView();
		String msg="please enter valid Reason";
		String alert="alert alert-danger";
		System.out.println("nnnnnnnnnnnnnnnnnnnnnn"+appointment.getReason());
		HttpSession s=req.getSession(false);
		int uid=(int)s.getAttribute("uid");
		appointment.setUserid(uid); 
		try {
			msg="Your Request Successfully Submited";
			alert="alert alert-success";
			System.out.println("nnnnnnnnnnnnnnnnnnnnnn"+appointmentService.getUser(uid));
			if(appointmentService.getUser(uid)==0) {
			appointmentService.Appointmentsave(appointment);
			Appointment app=appointmentService.getStatus(uid);
			
			mv.addObject("appointment", app);
			mv.addObject("msg", msg);
			mv.setViewName("appointmentstatus");
		}
			else {
				msg="  Request Already submited";
				Appointment app=appointmentService.getStatus(uid);
				System.out.println("nnnnnnnnnnnnnnnnnnnnnn"+appointment.getStatus());
				if(appointment.getStatus().equals("accept")) {
					msg="Request Accepted";
				}
				mv.addObject("appointment", app);
				mv.addObject("msg", msg);
				mv.setViewName("appointmentstatus");
			
			}
		}
		catch(Exception ex) {
		
			
			mv.addObject("alert", alert);
			mv.addObject("msg", msg);
			mv.setViewName("addapointmentdates");
		}
		return mv;
		
	}
	
	
	
	@PostMapping(value="/usersave")
	public ModelAndView userSave(@Valid @ModelAttribute("user")  UserRegister user,BindingResult result,@RequestParam String email,@RequestParam String password ) {
		ModelAndView mv=new ModelAndView();
		String message="user already registred ";
		
		
		if(result.hasErrors()) {
			
			mv.addObject("msg", message);
			mv.setViewName("userRegister");
		}
		else {
			try {
			message="";
			
			userRegisterService.userSave(user);
			
			try {
			
		
			user=userRegisterService.userLogin(email,password);
		
		int id=user.getUid();
		System.out.println("ssssssssssssssssssssssssssssssssssss"+id);
		String Loginid="slry"+"srcp"+id;
		String s1[]= {email};
		com.salurysrcp.gmail.SendMailing.send("salurysrcp@gmail.com","salurysrcp123",s1, "heartly welcome to salur ysrcp","Thankyou for joining salur ysrcp family your Login id:   "
		+Loginid+"    please Remember this id for future use"); 
		String alert="alert alert-success";
		
		message="please check your mail verfiy your Login Id";
		mv.addObject("alert", alert);
		mv.addObject("users", user);
		mv.addObject("msg", message);
		mv.setViewName("home");
		}
		catch(Exception ex) {
			String alert="alert alert-success";
			mv.addObject("alert", alert);
			message="invalid mailid";
			mv.addObject("msg", message);
			mv.setViewName("userRegister");
		}
			
			}
			catch(Exception ex) {
				mv.addObject("msg", message);
				mv.setViewName("userRegister");
			}
		}
		return mv;
	}
	
	@GetMapping(value="/resendLoginId")
	public ModelAndView resendLoginId(HttpServletRequest req) {
		ModelAndView mv=new ModelAndView();
		String alert="alert alert-info";
		String msg="";
		
		HttpSession s=req.getSession(false);
		int uid=(int)s.getAttribute("uid");
		String email=(String)s.getAttribute("email");
		System.out.println("ddddddddddddddddddddddddddd"+email+uid);
		String Loginid="slry"+"srcp"+uid;
		String s1[]= {email};
		
		try {
		com.salurysrcp.gmail.SendMailing.send("salurysrcp@gmail.com","salurysrcp123",s1, "heartly welcome to salur ysrcp","Thankyou for joining salur ysrcp family your Login id:   "
		+Loginid+"    please Remember this id for future use");
		mv.setViewName("AppointmentVerfication");
		mv.addObject("msg", msg);
		mv.addObject("alert", alert);
		}catch(Exception ex){
			System.out.println(ex.getMessage());
			 alert="alert alert-danger";
			 msg="Server Busy Please  try Again Later";
			 mv.setViewName("AppointmentVerfication");
				mv.addObject("msg", msg);
				mv.addObject("alert", alert);
		}
		return mv;
	}
	
	@GetMapping(value="/appointmentid")
	public ModelAndView AppointmentLogin(HttpServletRequest req) {
		ModelAndView mv =new ModelAndView();
		String LoginId=req.getParameter("loginid");
		String msg="";
		String alert="alert alert-danger";
		System.out.println("aaaaaaaaaaaa"+LoginId);
		String LoginId1[]=LoginId.split("p");
		
		HttpSession s=req.getSession(false);
		int uid=(int)s.getAttribute("uid");
		String id=String.valueOf(uid);
		System.out.println("aaaaaaaaaaaa"+LoginId1[1]);
		System.out.println("aaaaaaaaaaaa"+LoginId1[1].equals(id));
		try {
		if(LoginId1[1].equals(id)) {
			alert="alert alert-info";
			mv.setViewName("addapointmentdates");
			mv.addObject("appointment", new Appointment());
			mv.addObject("msg", msg);
		}
		else {
			
			msg="Invalid LogIn Id";
			mv.setViewName("AppointmentVerfication");
			mv.addObject("msg", msg);
			
			mv.addObject("alert", alert);
		}
		}
		catch(Exception ex) {
			msg="Invalid LogIn Id";
			mv.setViewName("AppointmentVerfication");
			mv.addObject("msg", msg);
			mv.addObject("alert", alert);
		}
		return mv;
	}
	
	
	@PostMapping(value="/updateUser")
	public ModelAndView updateUser(@Valid @ModelAttribute("user")  UserRegister user,BindingResult result,@RequestParam String fullname,
			@RequestParam String fathername,@RequestParam String mobile,@RequestParam @DateTimeFormat(pattern="yyyy-MM-dd")
	Date dob,@RequestParam String gender,@RequestParam String email,@RequestParam String village,@RequestParam String town,
	@RequestParam int wardno,@RequestParam String street,HttpServletRequest req) {
		ModelAndView mv=new ModelAndView();
		String msg="";
		HttpSession s=req.getSession(false);
		try {
			int uid=(int)s.getAttribute("uid");
			//Date dob1=new SimpleDateFormat("yyyy/MM/dd").parse(dob);  
			// user= userRegisterService.updateUser(fullname, fathername, mobile, dob, gender, email, village, town, wardno, street, uid);
			user= userRegisterService.getUserProfile(uid);
			mv.addObject("user", user);
			user.setFullname(fullname);
			user.setFathername(fathername);
			user.setMobile(mobile);
			user.setDob(dob);
			user.setGender(gender);
			user.setEmail(email);
			user.setVillage(village);
			user.setTown(town);
			user.setWardno(wardno);
			userRegisterService.userSave(user);
			System.out.println("dddddddddddddddddddddddddddddddddddddddddd"+user.getWardno());
			msg="successfully updated";
			String alert="alert alert-success";
			mv.addObject("alert", alert);
			mv.addObject("msg", msg);
			mv.setViewName("EditProfile");
			return mv;
			
		}
		catch(Exception ex) {
			System.out.println("ssssssssssssssssssssssssssssssssssss"+ex.getMessage() );
			String alert="alert alert-danger";
			mv.addObject("alert", alert);
			msg="User Not Updated please try again";
			mv.addObject("msg", msg);
			mv.setViewName("EditProfile");
			return mv;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	@CrossOrigin()
	@PostMapping(value="/userLogin")
	public ModelAndView userLogin(@RequestParam("email") String email,@RequestParam("password") String password,HttpServletRequest req) {
		System.out.println(password);
		ModelAndView mv=new ModelAndView();
		String msg="Invalid email and password";
		HttpSession s=req.getSession(true);
		try {
			System.out.println(password+"vvvvvvvvvvvvvvvvvvvvvvvvvvvv");
		UserRegister user=userRegisterService.userLogin(email, password);
		System.out.println(password+"vvvvvvvvvvvvvvvvvvvvvvvvvvvv"+user.getFullname());
		String username=user.getFullname();
		String block=user.getBlock();
		System.out.println(password+"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"+block);
		
		 if(username.equals("root")){
				System.out.println(password+"vvvvvvvvvvvvvvvvvvvvvvvvvvvv"+user.getUid());
				msg="";
				mv.addObject("msg", msg);
				
				s.setAttribute("uid", user.getUid());
				s.setAttribute("email", user.getEmail());
				mv.addObject("name", user.getFullname());
				mv.setViewName("rootwelcome");
			}
			
		 else if(block.equals("yes")) {
				msg="your Account Blocked Due To InSufficient Data !Please Contact Nearest Ysrcp Office";
				mv.addObject("msg", msg);
				mv.setViewName("home");
				
			}
			else{
				System.out.println(password+"vvvvvvvvvvvvvvvvvvvvvvvvvvvv"+user.getFullname());
				System.out.println(password+"sssssssssssssssssssssssssss"+user.getUid());
				
				msg=" ";
				mv.addObject("msg", msg);
				s.setAttribute("uid", user.getUid());
				s.setAttribute("email", user.getEmail());
				String userid="slr"+user.getUid()+"ysrcp";
				String[] s1={"apmrv05@gmail.com","ramakrishnaecec7@gmail.com","ramakrishna.routhu@spsoft.in"};
				mv.addObject("name", user.getFullname());
				mv.setViewName("welcome");
				/* MimeMessage message = sender.createMimeMessage();
			        MimeMessageHelper helper = new MimeMessageHelper(message);
			        try {
			            helper.setTo("ramakrishnaecec7@gmail.com");
			            helper.setText("Greetings :)");
			            helper.setSubject("Mail From Spring Boot");
			        } catch (MailException e) {
			            e.printStackTrace();
			           
			        }
			        sender.send(message);*/
				
			
				//com.salurysrcp.gmail.SendMailing.send("salurysrcp@gmail.com","salurysrcp123",s1, "hello apmrv","How r u?"); 
			}
			
		}
		catch(Exception ex) {
			System.out.println(password+"vvvvvvvvvvvvvvvvvvvvvvvvvvvv"+ex.getMessage());
			mv.addObject("msg", msg);
			mv.setViewName("home");
			System.out.println(password+"pppppppppppppppppppppppppppppp");
		}
		
		
		return mv;
	}
	@CrossOrigin()
	@GetMapping(value="/logout")
	public ModelAndView logOut(HttpServletRequest req) {
		ModelAndView mv=new ModelAndView("home");
		HttpSession s=req.getSession();
		s.invalidate();
		return mv;
		
	}
	@CrossOrigin()
	@PostMapping(value="/forget")
	public ModelAndView forgetpassword(@RequestParam("email") String email,@RequestParam("password") String password) {
		
		ModelAndView mv=new ModelAndView();
		String msg="this email is not Register Please Register";
		try {
			UserRegister user=userRegisterService.forgetpassword(email, password);
			if(user!=null) {
				msg="update successfully";
				mv.addObject("user", user);
				mv.addObject("msg", msg);
				mv.setViewName("home");
			}
		}
		catch(Exception ex) {
			mv.addObject("msg", msg);
			mv.setViewName("home");
		}
		
		return mv;
	}
	
	
@PostMapping(value="/savefile")	
public ModelAndView saveFile(
            @RequestParam("file") CommonsMultipartFile[] file,HttpServletRequest request) {
	ModelAndView mv=new ModelAndView();
	String msg="file upload successfully";
	
	try {
		System.out.println("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww1111111");
	
	
	HttpSession session = request.getSession(false);
	if(session.isNew()) {
		System.out.println("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww222222222");
	 HttpSession s=request.getSession();
	}
	 System.out.println("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww233333333333");
	 Integer uid=(Integer) session.getAttribute("uid");
	 System.out.println("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww4444444444"+uid);
	UserRegister user=fileUploadService.getUser(uid);
	int count=fileUploadService.getCount(uid);
	if(count>=2) {
		if (file != null && file.length > 0) {
            for (CommonsMultipartFile aFile : file){
            	System.out.println("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
                System.out.println("Saving file: " + aFile.getOriginalFilename());
                
                
                 
               List<FileUpload> fileUpload = fileUploadService.updatephoto(uid);
              for(FileUpload f:fileUpload) {
                f.setFilename(aFile.getOriginalFilename());
                f.setContent(aFile.getBytes());
                f.setUserRegister(user);    
                fileUploadService.saveFile(f);
               
              }
              mv.addObject("file", fileUpload);
              mv.addObject("msg", msg);
              mv.setViewName("welcome");
            }
        }
		
	}
	
	
	else {
	System.out.println("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww1"+user.getUid());
		if (file != null && file.length > 0) {
            for (CommonsMultipartFile aFile : file){
            	System.out.println("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww1");
                System.out.println("Saving file: " + aFile.getOriginalFilename());
                
                
                 
                FileUpload fileUpload = new FileUpload();
              
                fileUpload.setFilename(aFile.getOriginalFilename());
                fileUpload.setContent(aFile.getBytes());
                fileUpload.setUserRegister(user);    
                fileUploadService.saveFile(fileUpload);
                mv.addObject("file", fileUpload);
                mv.addObject("msg", msg);
                mv.setViewName("welcome");
            }
        }
	}
	}catch(Exception ex) {
		System.out.println("sssssssssssssssssss"+ex.getMessage());
		msg="fail not upload Please try again";
		 mv.addObject("msg", msg);
         mv.setViewName("uploadimage");
		
	}
		return mv;
	}
	
/*@GetMapping(value="/userprofile")
public void usersprofile(HttpServletRequest req) {
	HttpSession session = req.getSession(false);
	 Integer uid=(Integer) session.getAttribute("uid");
	UserRegister user=userRegisterService.ge
}*/
@CrossOrigin()
@GetMapping(value="/getprofile")
public ModelAndView getUserProfile(HttpServletRequest request,HttpServletResponse response) {
	ModelAndView mv=new ModelAndView();
	String msg="";
	try {
		
	HttpSession session = request.getSession(false);
	int uid=(int)session.getAttribute("uid");
	System.out.println("ffffffffffffffffffffffffffffffffffff"+uid);
	UserRegister user=userRegisterService.getUserProfile(uid);
	
	System.out.println("ffffffffffffffffffffffffffffffffffff"+user.getDob());
	FileUpload file=fileUploadService.getphoto(uid);
	FileUpload aadhar=fileUploadService.getAadhar(6);
	System.out.println("ffffffffffffffffffffffffffffffffffff"+aadhar.getFilename());
	


	//response.getOutputStream().write(b);
String base64Image="";
if(file!=null) {
	System.out.println("gggggggggggggggggggggggggggggggggggggggggggg");
	byte b[]=file.getContent();
	msg="Edit photo";
	  base64Image = Base64.getEncoder().encodeToString(b);
}
else {
	System.out.println("ffffffffffffffffffffffffffffffffffff");
	byte a[]=aadhar.getContent();
	msg="upload photo here";
	base64Image = Base64.getEncoder().encodeToString(a);
}
	
   
    System.out.println("gggggggggggggggggggggggggggggggggggggggggggggggggg");
    mv.addObject("image",base64Image);
    mv.addObject("msg", msg);
	mv.addObject("user", user);
	mv.setViewName("viewprofile");
	
	
	}
	catch(Exception ex) {
		msg="user details not found";
		mv.addObject("msg", msg);
		mv.setViewName("welcome");
	}
	return mv;
}






@GetMapping(value="/userIDList")
public ModelAndView userListID(Model model) {
	ModelAndView mv=new ModelAndView();
	mv.setViewName("userIdList");
	model.addAttribute("user", new UserRegister());
	
	return mv;
}








@CrossOrigin()
@GetMapping(value="/getVillageList")
public ModelAndView getVillageList(HttpServletRequest request,HttpServletResponse response) {
	ModelAndView mv=new ModelAndView();
	String msg="";
	String village=request.getParameter("village");
	System.out.println("ffffffffffffffffffffffffffffffffffff"+village);
	try {
		
	HttpSession session = request.getSession(false);
	//int uid=(int)session.getAttribute("uid");
	List<UserRegister> list=new ArrayList<UserRegister>();
	list=userRegisterService.getVillageList(village);
	
	
	mv.setViewName("getVillageList");
	mv.addObject("list", list);
	
	}
	catch(Exception ex) {
		msg="user details not found";
		mv.addObject("msg", msg);
		mv.setViewName("rootwelcome");
	}
	return mv;
}

@GetMapping(value="/villageList")
public ModelAndView villageList(Model model) {
	ModelAndView mv=new ModelAndView();
	mv.setViewName("villageList");
	model.addAttribute("user", new UserRegister());
	
	return mv;
}


@GetMapping(value="/townList")
public ModelAndView townList(Model model) {
	ModelAndView mv=new ModelAndView();
	mv.setViewName("TownList");
	model.addAttribute("user", new UserRegister());
	
	return mv;
}





@GetMapping(value="/getTownList")
public ModelAndView getTownList(HttpServletRequest request,HttpServletResponse response) {
	ModelAndView mv=new ModelAndView();
	String msg="";
	String town=request.getParameter("town");
	System.out.println("ffffffffffffffffffffffffffffffffffff"+town);
	try {
		
	HttpSession session = request.getSession(false);
	//int uid=(int)session.getAttribute("uid");
	List<UserRegister> list=new ArrayList<UserRegister>();
	list=userRegisterService.getTownList(town);
	
	
	mv.setViewName("getTownList");
	mv.addObject("list", list);
	
	}
	catch(Exception ex) {
		msg="user details not found";
		mv.addObject("msg", msg);
		mv.setViewName("rootwelcome");
	}
	return mv;
}






@GetMapping(value="/getBlockList")
public ModelAndView getblockedUsers(HttpServletRequest request,HttpServletResponse response) {
	ModelAndView mv=new ModelAndView();
	String msg="";
	String town=request.getParameter("town");
	
	try {
		
	HttpSession session = request.getSession(false);
	//int uid=(int)session.getAttribute("uid");
	List<UserRegister> list=new ArrayList<UserRegister>();
	list=userRegisterService.geBlockedUser();
	
	System.out.println("ffffffffffffffffffffffffffffffffffff"+list.size());
	mv.setViewName("getBlockedList");
	mv.addObject("list", list);
	
	}
	catch(Exception ex) {
		msg="user details not found";
		mv.addObject("msg", msg);
		mv.setViewName("rootwelcome");
	}
	return mv;
}















@GetMapping(value="/getUserIDList")
public ModelAndView getUserIDList(HttpServletRequest request,HttpServletResponse response) {
	ModelAndView mv=new ModelAndView();
	String msg="";
	int uid=Integer.parseInt(request.getParameter("userid"));
	System.out.println("ffffffffffffffffffffffffffffffffffff"+uid);
	try {
		
	HttpSession session = request.getSession(false);
	//int uid=(int)session.getAttribute("uid");
	List<FileUpload> list=new ArrayList<FileUpload>();
	UserRegister user=userRegisterService.getUserProfile(uid);
	
	System.out.println("ffffffffffffffffffffffffffffffffffff"+user.getDob());
	 list=fileUploadService.updatephoto(uid);
	FileUpload aadhar=fileUploadService.getAadhar(6);
	System.out.println("ffffffffffffffffffffffffffffffffffff"+aadhar.getFilename());
	


	//response.getOutputStream().write(b);
	ArrayList<String> base64=new ArrayList<>();
	
String base64Image="";
if(list!=null) {
	
	
	for(FileUpload file:list) {
		
	byte b[]=file.getContent();
	int useridd=file.getUid();
	
	msg="Edit photo";
	  base64Image = Base64.getEncoder().encodeToString(b);
	  base64.add(base64Image);
	 
	}
}
else {
	System.out.println("ffffffffffffffffffffffffffffffffffff");
	byte a[]=aadhar.getContent();
	msg="upload photo here";
	base64Image = Base64.getEncoder().encodeToString(a);
	 base64.add(base64Image);
}
	
   
    System.out.println("gggggggggggggggggggggggggggggggggggggggggggggggggg");
   
    mv.addObject("image",base64);
    
    mv.addObject("msg", msg);
	mv.addObject("user", user);
	mv.setViewName("getuseridList");
	
	
	}
	catch(Exception ex) {
		msg="user details not found";
		mv.addObject("msg", msg);
		mv.setViewName("rootwelcome");
	}
	return mv;
}





























/*@GetMapping(value="/getimage/{uid}")
@ResponseBody
public byte[] getPhoto(HttpServletRequest request,HttpServletResponse response, @PathVariable int uid) {
	System.out.println("ffffffffffffffffffffffffffffffffffff");
	ModelAndView mv=new ModelAndView();
	String msg="image not upload";
	
		
		HttpSession session = request.getSession(false);
		 uid=(int)session.getAttribute("uid");
		System.out.println("ffffffffffffffffffffffffffffffffffff"+uid);
		FileUpload file=fileUploadService.getphoto(uid);
		
		byte[] image=file.getContent();
		System.out.println("ggggggggggggggggggggggggggggggggggggggggggg"+file.getFileid());
	        response.setContentType("\"image/jpeg, image/jpg, image/png, image/gif\"");
	        response.setContentLength(file.getContent().length);
	        response.setHeader("Content-Disposition","attachment; filename=\"" + file.getFilename() +"\"");
	        System.out.println("ggggggggggggggggggggggggggggggggggggggggggg"+file.getFilename());
	        FileCopyUtils.copy(file.getContent(), response.getOutputStream());
	        System.out.println("ffffffffffffffffffffffffffffffffffff"+uid);
	       
	
		 System.out.println("image not found");
		 
		 return image;
	
}*/
@CrossOrigin()
	@GetMapping(value="/getimage/{iid}")
	public void getImage(HttpServletRequest request,HttpServletResponse response,@PathVariable int iid) throws IOException {
		HttpSession session = request.getSession(false);
		int uid=(int)session.getAttribute("uid");
		System.out.println("ffffffffffffffffffffffffffffffffffff"+uid);
		
		FileUpload file=fileUploadService.getphoto(uid);
		iid=file.getFileid();
		String filename=file.getFilename();
		byte b[]=file.getContent();
		 response.setContentType("\"image/jpeg, image/jpg, image/png, image/gif\"");
		 response.setHeader("Content-Disposition","attachment; filename=\"" + file.getFilename() +"\"");
		 response.getOutputStream().write(b);
		
	}
	
	
	
@GetMapping(value="/getUserDocuments")
public ModelAndView getUserDocuments(HttpServletRequest request,HttpServletResponse response) {
	ModelAndView mv=new ModelAndView();
	String msg="";
	
	List<FileUpload> list=new ArrayList<FileUpload>();
	
	
	try {
	 list=fileUploadService.allPhotos();
	 System.out.println("ffffffffffffffffffffffffffffffffffff"+list.size());
	//FileUpload aadhar=fileUploadService.getAadhar(6);
	//System.out.println("ffffffffffffffffffffffffffffffffffff"+aadhar.getFilename());
	


	//response.getOutputStream().write(b);
	ArrayList<String> base64=new ArrayList<>();
String base64Image="";
if(list!=null) {
	System.out.println("gggggggggggggggggggggggggggggggggggggggggggg");
	
	for(FileUpload file:list) {
		
	byte b[]=file.getContent();
	System.out.println("gggggggggggggggggggggggggggggggggggggggggggg"+file.getUid());
	msg="Edit photo";
	  base64Image = Base64.getEncoder().encodeToString(b);
	  base64.add(base64Image);
	}
}

	
   
    System.out.println("gggggggggggggggggggggggggggggggggggggggggggggggggg");
   
    mv.addObject("image",base64);
    
    mv.addObject("msg", msg);
	
	mv.setViewName("UserDocument");
	
	
	}
	catch(Exception ex) {
		msg="user details not found";
		mv.addObject("msg", msg);
		mv.setViewName("rootwelcome");
	}
	return mv;
}



	
	
	
	
	
	
	
	
	
	
	
	@PostMapping(value="/DeptSave")
	public ModelAndView savedept(@Valid Department dept,BindingResult result) {
		ModelAndView mv=new ModelAndView();
		
		if(result.hasErrors()) {
		
		mv.addObject("emp",new Department());
		mv.setViewName("register");
		
		return mv;
		}
		es.depsave(dept);
		String msg="sucessfully inserted";
		Employee e=new Employee();
		mv.addObject("msg",msg);
		mv.addObject("dept",dept);
		e.setDept(dept);
		mv.addObject("emp",e);
		mv.setViewName("deptsave");
		return mv;
		
	}
	@GetMapping(value="/viewemp")
	public ModelAndView getEmpolyee(@RequestParam("eno") int eno) {
		ModelAndView mv=new ModelAndView("save");
		Employee emp=es.getEmployee(eno);
		mv.addObject("emp",emp);
		mv.setViewName("view");
		
		return mv;
		
	}
	@PostMapping(value="/update")
	public ModelAndView updateemployee(@RequestParam("eno") int eno,@RequestParam String ename) {
		ModelAndView mv=new ModelAndView("view");
		Employee emp=es.updatetEmployee(eno,ename);
		mv.addObject("emp",emp);
		mv.setViewName("update");
		
		return mv;
		
	}
	
	
	
	@GetMapping(value="/blocked")
	public ModelAndView blocklist(Model model) {
		String msg="";
		ModelAndView mv=new ModelAndView();
		mv.setViewName("blocked");
		model.addAttribute("user", new UserRegister());
		mv.addObject("msg", msg);
		
		return mv;
	}
	
	
	@GetMapping(value="/getblocked")
	public ModelAndView betBlocklist(HttpServletRequest req) {
		ModelAndView mv=new ModelAndView();
		String msg="User Successfully blocked";
		String block=req.getParameter("block");
		
		int uid=Integer.parseInt(req.getParameter("uid"));
		 System.out.println("gggggggggggggggggggggggggggggggggggggggggggggggggg"+block+uid);
		try {
		UserRegister user=userRegisterService.getUserProfile(uid);
		user.setBlock(block);
		userRegisterService.userSave(user);
		mv.setViewName("blocked");
		
		mv.addObject("user", new UserRegister());
		mv.addObject("msg", msg);
		
		}
		catch(Exception ex) {
			msg="user Not Found Please Checkl Again";
			mv.setViewName("blocked");
			mv.addObject("msg", msg);
			
			
		}
		return mv;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}























