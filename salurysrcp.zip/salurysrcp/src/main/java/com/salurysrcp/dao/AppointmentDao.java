package com.salurysrcp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.salurysrcp.entity.Appointment;


public interface AppointmentDao extends CrudRepository<Appointment,Integer>{
@Query(value="select id,reason,priority,status,userid from appointment where userid=?1",nativeQuery=true)
Appointment getStatus(int userid);
@Query(value="select count(userid) from appointment where userid=?1",nativeQuery=true)
int getUser(int userid);
@Query(value="select id,reason,priority,status,userid from appointment ",nativeQuery=true)
List<Appointment> getRequstes();
@Query(value="delete id,reason,priority,status,userid from appointment where userid=?1",nativeQuery=true)
void deleteRequest(int userid);
@Query(value="update appointment set status=?1 from appointment where userid=?1",nativeQuery=true)
void updateRequest(int userid);
}
