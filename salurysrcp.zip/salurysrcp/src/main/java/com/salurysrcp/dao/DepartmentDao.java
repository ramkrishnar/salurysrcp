package com.salurysrcp.dao;

import org.springframework.data.repository.CrudRepository;

import com.salurysrcp.entity1.Department;


public interface DepartmentDao  extends CrudRepository<Department,Integer>{
public Department findBydeptNo(int dept);

}
