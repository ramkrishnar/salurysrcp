package com.salurysrcp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.salurysrcp.entity.FileUpload;



public interface FileUploadDao extends CrudRepository<FileUpload,Integer>  {
@Query(value="select fileid,content,filename,uid from file_upload group by uid=?1 limit 1,1" ,nativeQuery=true)
FileUpload getPhoto(int uid);
@Query(value="select fileid,content,filename,uid from file_upload where fileid=?1" ,nativeQuery=true)
FileUpload getAadhar(int fileid);
@Query(value="select count(*) from file_upload where uid=?1", nativeQuery=true)
int getCount(int uid);
@Query(value="select * from file_upload where uid=?1",nativeQuery=true)
List<FileUpload> updatephoto(int uid);
@Query(value="select * from file_upload order by uid asc",nativeQuery=true)
List<FileUpload> allPhotos();
}
