package com.salurysrcp.dao;



import org.springframework.data.repository.CrudRepository;

import com.salurysrcp.entity1.Department;
import com.salurysrcp.entity1.Employee;


public interface EmployeeDao extends CrudRepository<Employee,Integer>  {
	public Employee findByempNo(int eno);
	

	

}
