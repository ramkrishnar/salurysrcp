package com.salurysrcp.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.salurysrcp.entity.UserRegister;

public interface UserRegisterDao extends CrudRepository<UserRegister,Integer> {
public UserRegister findByEmailAndPassword(String email,String password);
public UserRegister findByEmail(String email);
public UserRegister findByUid(int uid);
@Query(value="select * from user_master   where uid=?1", nativeQuery=true)
UserRegister getUserDetails(int uid);
@Query(value="select * from user_master   where village=?1", nativeQuery=true)
List<UserRegister> getVillageList(String village);
@Query(value="select distinct(u.uid),u.fullname,u.fathername,u.mobile,u.gender,u.email,u.dob,u.password,f.filename,f.content from user_master u inner join file_upload f on u.uid=f.uid where u.uid=?1", nativeQuery=true)
UserRegister getPhoto(int uid);
@Query(value="update user_master set fullname=?1,fathername=?2,mobile=?3,dob=?4,gender=?5,email=?6,village=?7,town=?8,wardno=?9,street=?10 where uid=?11",nativeQuery=true)
UserRegister updateUser(String fullname,String fathername,String mobile,String dob,String gender,String email,String village,String town,int wardno,String street,int uid);
@Query(value="select * from user_master   where town=?1", nativeQuery=true)
public List<UserRegister> getTownList(String town);
@Query(value="SELECT * FROM slrysrcp.user_master where block='yes'", nativeQuery=true)
List<UserRegister> getBlockedUsers();

}
