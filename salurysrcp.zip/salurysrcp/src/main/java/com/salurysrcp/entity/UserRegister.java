package com.salurysrcp.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.format.annotation.DateTimeFormat;

import com.salurysrcp.entity1.Employee;
@Entity
@Table(name="user_master")
public class UserRegister {
	
	public UserRegister() {
		
	}
	
	
	@Id
	@GeneratedValue(generator="myGenerator")
	@GenericGenerator(name="myGenerator",
	strategy="increment")
	@Column(name="uid")
	private int uid;
	@Column(name="fullname")
	@NotNull
	private String fullname;
	@Column(name="fathername")
	@NotNull
	private String fathername;
	@Column(name="mobile")
	@NotNull
	@Size(min=10,max=11)
	private String mobile;
	@Column(name="dob")
	@NotNull
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dob;
	@Column(name="gender")
	private String gender;
	@Column(name="email")
	@NotNull
	@Email
	private String email;
	@Column(name="password")
	@NotNull
	 @Size(min=8,max=15)
	private String password;
	@Column(name="filename")
	private String filename="";
	private String village="";
	private String town="";
	private Integer wardno=0;
	private String Street="";
	private String block="no";
	
	
	


	public String getBlock() {
		return block;
	}
	public void setBlock(String block) {
		this.block = block;
	}
	public void setWardno(Integer wardno) {
		this.wardno = wardno;
	}


	@Transient
	@Size(min=8,max=15)
	private String confirmpassword;
	@OneToMany(mappedBy="userRegister")
	private List<FileUpload> fileUpload;
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public String getVillage() {
		return village;
	}
	public void setVillage(String village) {
		this.village = village;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public int getWardno() {
		return wardno;
	}
	public void setWardno(int wardno) {
		this.wardno = wardno;
	}
	public String getStreet() {
		return Street;
	}
	public void setStreet(String street) {
		Street = street;
	}
	public List<FileUpload> getFileUpload() {
		return fileUpload;
	}
	public void setFileUpload(List<FileUpload> fileUpload) {
		this.fileUpload = fileUpload;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFilename() {
		return filename;
	}
	public String getFathername() {
		return fathername;
	}
	public void setFathername(String fathername) {
		this.fathername = fathername;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	
	
}
