package com.salurysrcp.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="file_upload")
public class FileUpload {
	@Id
	@GeneratedValue(generator="myGenerator")
	@GenericGenerator(name="myGenerator",
	strategy="increment")
	private int fileid;
	@Transient
	private int uid;
	private String filename;
	@Lob @Basic(fetch = FetchType.LAZY)
    @Column(name="content", nullable=false)
    private byte[] content;
	 public int getFileid() {
		return fileid;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public void setFileid(int fileid) {
		this.fileid = fileid;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public byte[] getContent() {
		return content;
	}
	public void setContent(byte[] content) {
		this.content = content;
	}
	public UserRegister getUserRegister() {
		return userRegister;
	}
	public void setUserRegister(UserRegister userRegister) {
		this.userRegister = userRegister;
	}
	@ManyToOne(optional = false)
	    @JoinColumn(name = "uid")
	private UserRegister userRegister;

}
